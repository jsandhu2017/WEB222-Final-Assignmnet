function validateFirstName() {
  let valid = true
  let allAlpha = true;
  let captialLetter = true;
  let elem = document.querySelector("#firstName");
  let inputValue = elem.value.trim();
  let firstLetter = inputValue[0];
  inputValue = inputValue.toUpperCase();

  for (let i = 0; i < inputValue.length; i++) {
       // check all characters are letters
       if (inputValue.charAt(i) < "A" || inputValue.charAt(i) > "Z" )  { allAlpha = false; }
  }

  if (firstLetter != firstLetter.toUpperCase()) {captialLetter = false}

  if (captialLetter == false || allAlpha == false)
  {
    valid = false;
  }

  return valid;
}

function validateLastName() {
  let valid = true
  let allAlpha = true;
  let captialLetter = true;
  let elem = document.querySelector("#lastName");
  let inputValue = elem.value.trim();
  let firstLetter = inputValue[0];
  inputValue = inputValue.toUpperCase();

  for (let i = 0; i < inputValue.length; i++) {
       // check all characters are letters
       if (inputValue.charAt(i) < "A" || inputValue.charAt(i) > "Z" )  { allAlpha = false; }
  }

  if (firstLetter != firstLetter.toUpperCase()) {captialLetter = false}

  if (captialLetter == false || allAlpha == false)
  {
    valid = false;
  }

  return valid;
}

function validateArrSize(arr, size){
  let valid = false;
  if(arr.length >= size) {valid = true};
  return valid;
}

function validateAlpha(arr){
  let passAlpha = false;
  let alphString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  for (let i = 0; i < alphString.length; i++) {
    for(let j = 0; j < arr.length; j++)
    {
      if (alphString[i] == arr[j]) { passAlpha = true; }
    }
  }  
	return passAlpha;
}

function validatePasswords() {
  let elem = document.querySelector("#password")
  let inputValue = elem.value;
  let digitsArr = "0123456789";
  let valid = false;
  valid = validateArrSize(inputValue, 6);
  if (valid == true)
  {
    valid = validateAlpha(inputValue);
    if(valid == true)
    {
      let count = 0;
      for(let i =0; i < inputValue.length; i++)
      {
        if (inputValue.charAt(i) != inputValue[i].toUpperCase()){count++;}
      }
      if(count > 0){valid = true;}
      else {valid = false;}
      
      if(valid)
      {
        let count = 0;
        for(let i=0; i < inputValue.length;i++)
        {
          for(let j=0; j < digitsArr.length;j++)
          {
            if(inputValue.charAt(i) == digitsArr.charAt(j)){count++;}
          }
        }
        if(count > 0){valid = true;}
        else {valid = false;}
      }
    }
  }
  return valid;
}

function validateConfirmPasswords() {
  let elem = document.querySelector("#password")
  let inputValue = elem.value.trim;
  elem = document.querySelector("#password2")
  let inputValue2 = elem.value.trim;
  let valid = false;
  if (inputValue == inputValue2) {valid = true}
  return valid;
}

function validateUsername() {
  let elem = document.querySelector("#userName");
  let inputValue = elem.vaule.trim;
  let valid = false;
  valid = validateAlpha()
  if (valid)
  {
    valid = validateArrSize(inputValue, 6);
  }
  return valid;
}

function showErrors(messages){
  document.querySelector("#error-messages").innerHTML += messages;
}

function clearErrors() {
  document.querySelector("#error-messages").innerHTML = "";
}

function formValidation() {
  let valid = true;
  let errorCount = 0;
  clearErrors();
  valid = validateFirstName();
  if(!valid)
  {
    
    if(errorCount < 5)
    {
      errorCount++;
      showErrors("First name: Must start with a cap and only alphabet allowed.\n")
    }
  }

  valid = validateLastName();
  if(!valid)
  {
    
    if(errorCount < 5)
    {
      errorCount++;
      showErrors("Last name: Must start with a cap and only alphabet allowed.\n")
    }
  }

  valid = validatePasswords();
  if(!valid)
  {
    if(errorCount < 5)
    {
      errorCount++;
      showErrors("Password: must be 6 characters long, must start with an alphabet, must have at least 1 digit and 1 uppercase.\n")
    }
  }

  valid = validateConfirmPasswords();
  if(!valid)
  {
    
    if(errorCount < 5)
    {
      errorCount++;
      showErrors("Both passwords must match.\n")
    }
  }

  valid = validateUsername();
  if(!valid)
  {
    
    if(errorCount < 5)
    {
      errorCount++;
      showErrors("Username: username must start with an alphabet, must have at least 6 characters.\n")
    }
  }

  if(errorCount > 0) {
    valid = false;
  }
  else {
    valid = true;
  }

  return valid;
}
